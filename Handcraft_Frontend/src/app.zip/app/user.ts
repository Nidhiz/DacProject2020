export class User {
 userName:String; 
 email:String; 
  password:String;
  address:String;
  contactNo:String;
  dob:String;
  city:String;
  state:String;
    gender:String;
    role:String;
    constructor(){}
           
}
