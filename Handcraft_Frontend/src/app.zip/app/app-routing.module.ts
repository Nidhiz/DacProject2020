import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { AdminProductListComponent } from './admin-product-list/admin-product-list.component';
import { ApplyDiscountComponent } from './apply-discount/apply-discount.component';
import { CartComponent } from './cart/cart.component';
import { ContactusComponent } from './contactus/contactus.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductUpdateComponent } from './product-update/product-update.component';
import { RegistrationComponent } from './registration/registration.component';
import { SupplierListComponent } from './supplier-list/supplier-list.component';
import { SupplierPanelComponent } from './supplier-panel/supplier-panel.component';
import { UserPanelComponent } from './user-panel/user-panel.component';

const routes: Routes = [

  {path:'', redirectTo:'home', pathMatch:'full'},

  {path:'home', component: HomeComponent},
  {path:'login', component: LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'aboutus', component: AboutusComponent},
  {path:'contactus', component: ContactusComponent},
  
  {path:'user-panel', component: UserPanelComponent},
  {path:'cart', component: CartComponent},
  {path:'gallery', component: GalleryComponent},


  {path:'supplier-panel', component: SupplierPanelComponent},
  {path:'product-list', component: ProductListComponent},
  {path:'product-add', component:ProductAddComponent},
  {path:'product-update', component:ProductUpdateComponent},
  {path:'product-update/:id', component:ProductUpdateComponent},
  

  {path:'admin-panel', component: AdminPanelComponent},
  {path:'admin-product-list', component:AdminProductListComponent},
  {path:'supplier-list', component:SupplierListComponent},
  {path:'apply-discount', component:ApplyDiscountComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
