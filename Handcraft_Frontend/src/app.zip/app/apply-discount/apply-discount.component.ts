import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { ProducthubService } from '../producthub.service';

@Component({
  selector: 'app-apply-discount',
  templateUrl: './apply-discount.component.html',
  styleUrls: ['./apply-discount.component.css']
})
export class ApplyDiscountComponent implements OnInit {

  product=new Product();
  
  constructor( private router: Router,private productService:ProducthubService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id = parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    let discountPercent = parseInt(this.activatedRoute.snapshot.paramMap.get('discountPercent'));
    this.productService.getProductByIdApplyDiscount(id,discountPercent).subscribe(
      Response=>{
        console.log("data received");
        this.product=Response;
      },
      error=>console.log("error")

    )
    
  }


  applyDiscount(){
    this.productService.addProductService(this.product).subscribe(
      Response=>{
        console.log("product updated successully");
        this.router.navigate(['/admin-product-list']);
      },
      error=>{
        console.log(error);

      }

    )

  }

 

}