import { Component, OnInit } from '@angular/core';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-supplier-panel',
  templateUrl: './supplier-panel.component.html',
  styleUrls: ['./supplier-panel.component.css']
})
export class SupplierPanelComponent implements OnInit {

  constructor() {  
   }

  ngOnInit(): void {
  }

}
